import java.text.NumberFormat;

/**
 * @author Jhenelle & Muhammad
 * Date: May 2017
 * Description: This program makes record objects for transactions. 
 * Method List:
 * 
 * 	TransactionRecord()- Constructor; initializes all private variables 
 * 	getTransactionType() - retrieves transaction Type
 * 	setTransactionType(String transactionType)- sets Transaction Type based on its input parameter 
 * 	getAmount() - retrieves amount 
 * 	setAmount(double amount)- sets user amount
 * 	getStartAMount() - retrieves start amount on user account 
 * 	setStartAmount(double startAmount)- sets starts amount from user account 
 * 	getEndAmount() - retrieves end account on account after transaction 
 * 	setEndAmount(double EndAmount)- sets end amount based on account 
 * 	getAccountType() - retrieves the type of account
 * 	setAccountType(char AccountType)- sets user account type 
 *	toString()- returns info as a String
 *	main (String [] args)- self testing method  
 *
 */
public class TransactionRecord {
	//declares variables 
	private String transactionType;
	private double transactionAmount, startAmount, endAmount;
	private char accountType;

	NumberFormat n = NumberFormat.getCurrencyInstance ();

	/*
	 * Default constructor
	 */
	public TransactionRecord()
	{
		//initialises variables 
		String transactionType="";
		double transactionAmount = 0;
		double startAmount =0;
		double endAmount = 0;
		char accountType = " ".charAt(0);
	}

	/*
	 * Constructor for transaction record display
	 */
	public TransactionRecord(char accountType, String transactionType, double transactionAmount, double startingBalance, double finalBalance) 
	{
		this.accountType = accountType;
		this.transactionType = transactionType;
		this.transactionAmount = transactionAmount;
		this.startAmount = startingBalance;
		this.endAmount = finalBalance;
	}


	public String getTransactionType() {
		return transactionType; // retrieves transaction type
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType; 
	}

	public double getTransactionAmount() {
		return transactionAmount; // retrieves amount 
	}

	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public double getStartAmount() {
		return startAmount; // retrieves start amount 
	}

	public void setStartAmount(double startAmount) {
		this.startAmount = startAmount;
	}

	public double getEndAmount() {
		return endAmount; // retrieves end amount 
	}

	public void setEndAmount(double endAmount) {
		this.endAmount = endAmount;
	}

	public char getAccountType() {
		return accountType; // retrieves end amount 
	}

	public void setAccountType(char accountType) {
		this.accountType = accountType;
	}

	/*
	 * toString method to convert symbol csdw to words
	 */
	public String toString(){
		String type = null;
		String tType = null;
		switch(this.transactionType)
		{
		case "w":
		{
			tType = "Withdraw";
			break;
		}
		case "d":
		{
			tType = "Deposit";
			break;
		}
		}
		switch(this.accountType)
		{
		case 'c':
		{
			type = "Chequing";
			break;
		}
		case 's':
		{
			type = "Savings";
			break;
		}
		}
		return (type + "\t          " + tType + "\t          " +  n.format(getTransactionAmount()) + "\t          " + n.format(getStartAmount()) + "\t" + n.format(getEndAmount())); 
	}

	public static void main(String[] args) {
		//self testing main

		TransactionRecord info = new TransactionRecord();
		//sets info 
		info.setTransactionType("w");
		info.setAccountType('s');
		info.setTransactionAmount(574.50);
		info.setStartAmount(950.00);
		info.setEndAmount(375.50);
		System.out.println(info.toString()); //calls toString method and displays info			
	}
}
