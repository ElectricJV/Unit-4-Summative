import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.NumberFormat;

import javax.swing.*;
import javax.swing.text.DefaultCaret;
/*
 * Date: April 20, 2017
 * Author: Muhammad Khan
 * Description: This program displays the main GUI for the customer
 * Method List: 
 * 		
 */

public class CustomerAccount extends JFrame implements ActionListener
{
	private static final long serialVersionUID = 1L;
	// Global variables for GUI elements, balances
	JButton btnHome, btnExit, btnLoadFile, btnSaveFile, btnWithdraw, btnDeposit, btnSort, btnClear;
	JToggleButton btnChequing, btnSavings;

	JTextArea txtAccountInfo, txtTransactionList, txtFinalBalance, txtWithdraw, txtSavings, txtDeposit;

	JLabel lblInfo;

	double amount = 0, currentBalance = 0;

	// Creating customer, savingsAcct, chequingAcct objects
	Customer customer = new Customer();
	Savings savingsAcct = new Savings(customer);
	Chequing chequingAcct = new Chequing(customer);
	// Creating record and transaction list objects
	TransactionRecord info = new TransactionRecord();
	TransactionList transactionList = new TransactionList();

	// Creating variables for fields and keys
	String input, output = "", file = "", type = "", name, address, phone, accountNum, username, password;
	char charType;
	int key;

	NumberFormat n = NumberFormat.getCurrencyInstance (); // Number format for currency
	Font f = new Font("Lucida Grande", Font.PLAIN, 16); // Create default font

	ActionListener listener = new ActionListener() // Get listener for buttons
			{
		public void actionPerformed(ActionEvent e) 
		{
			System.out.println("Button selected: " + e.getActionCommand());
			type = e.getActionCommand();
		}
			};

			/*
			 * Default constructor
			 */
			public CustomerAccount() 
			{
				setResizable(false);
				// try-catch with specific code to ensure the GUI is not distorted on a Windows computer
				try 
				{ // (https://docs.oracle.com/javase/7/docs/api/javax/swing/UIManager.html)
					UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
				} 
				catch (ClassNotFoundException e) 
				{
					e.printStackTrace();
				} 
				catch (InstantiationException e) 
				{
					e.printStackTrace();
				} 
				catch (IllegalAccessException e) 
				{
					e.printStackTrace();
				}
				catch (UnsupportedLookAndFeelException e) 
				{
					e.printStackTrace();
				}
				setSize (786-20, 840-35);
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				getContentPane().setLayout (null);
				setLocationRelativeTo (null);

				// Creating buttons and GUI elements
				ButtonGroup group = new ButtonGroup();
				btnChequing = new JToggleButton("Chequing");
				btnSavings = new JToggleButton("Savings");
				btnChequing.setFont(f);
				btnSavings.setFont(f);
				btnChequing.addActionListener(listener);
				btnSavings.addActionListener(listener);
				btnChequing.setBounds(102, 165, 138, 55);
				btnSavings.setBounds(511, 165, 138, 55);
				group.add(btnChequing);
				group.add(btnSavings);
				getContentPane().add(btnChequing);
				getContentPane().add(btnSavings);

				btnHome = new JButton("Home");
				btnHome.setToolTipText("Press to Return to Home Screen");
				btnHome.setFont(f);
				btnHome.setBounds(29, 706, 138, 55);
				getContentPane().add (btnHome);

				btnExit = new JButton("Exit");
				btnExit.setToolTipText("Press to Exit Program");
				btnExit.setFont(f);
				btnExit.setBounds(607, 706, 138, 55);
				getContentPane().add (btnExit);

				btnLoadFile = new JButton("Load File");
				btnLoadFile.setToolTipText("Press to Load a File");
				btnLoadFile.setFont(f);
				btnLoadFile.setBounds(250, 705, 143, 56);
				getContentPane().add (btnLoadFile);

				btnSaveFile = new JButton("Save File");
				btnSaveFile.setToolTipText("Press to write to file");
				btnSaveFile.setFont(f);
				btnSaveFile.setBounds(405, 704, 143, 58);
				getContentPane().add (btnSaveFile);

				btnWithdraw = new JButton("Withdraw");
				btnWithdraw.setToolTipText("Withdraw");
				btnWithdraw.setFont(f);
				btnWithdraw.setBounds(209, 630, 130, 41);
				getContentPane().add (btnWithdraw);

				btnDeposit = new JButton("Deposit");
				btnDeposit.setToolTipText("Deposit");
				btnDeposit.setFont(f);
				btnDeposit.setBounds(209, 577, 130, 41);
				getContentPane().add (btnDeposit);
				btnHome.addActionListener (this);
				btnExit.addActionListener (this);
				btnLoadFile.addActionListener (this);
				btnSaveFile.addActionListener (this);
				btnWithdraw.addActionListener(this);
				btnDeposit.addActionListener(this);

				txtAccountInfo = new JTextArea();
				txtAccountInfo.setLineWrap(true);
				txtAccountInfo.setEditable(false);
				txtAccountInfo.setFont(f);
				txtAccountInfo.setForeground(Color.BLACK);
				txtAccountInfo.setBounds(20, 37, 319, 86);
				getContentPane().add(txtAccountInfo);

				txtTransactionList = new JTextArea();
				txtTransactionList.setEditable(false);
				txtTransactionList.setFont(f);
				txtTransactionList.setForeground(Color.BLACK);
				txtTransactionList.setLineWrap(true);
				txtTransactionList.setBounds(29, 240, 696, 323);
				getContentPane().add(txtTransactionList);
				output += "Acct Type:"+ "\t" + "       Trans Type:" + "      Trans Amount:" + "     Initial Amount:" + "          " + "Final Amount:"
						+ "=====================================================\n";
				txtTransactionList.setText(output);
				DefaultCaret caret = (DefaultCaret)txtTransactionList.getCaret();
				caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

				txtFinalBalance = new JTextArea("");
				txtFinalBalance.setLineWrap(true);
				txtFinalBalance.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
				txtFinalBalance.setOpaque(false);
				txtFinalBalance.setEditable(false);
				txtFinalBalance.setBounds(64, 333, 184, 118);
				getContentPane().add(txtFinalBalance);

				lblInfo = new JLabel("Account Information");
				lblInfo.setFont(f);
				lblInfo.setBounds(20, 6, 219, 41);
				getContentPane().add(lblInfo);

				txtWithdraw = new JTextArea("");
				txtWithdraw.setLineWrap(true);
				txtWithdraw.setForeground(Color.BLACK);
				txtWithdraw.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
				txtWithdraw.setBounds(351, 634, 161, 29);
				getContentPane().add(txtWithdraw);

				txtDeposit = new JTextArea("");
				txtDeposit.setLineWrap(true);
				txtDeposit.setForeground(Color.BLACK);
				txtDeposit.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
				txtDeposit.setBounds(351, 582, 161, 29);
				getContentPane().add(txtDeposit);

				btnSort = new JButton("Sort");
				btnSort.setToolTipText("Sort");
				btnSort.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
				btnSort.setBounds(315, 196, 140, 24);
				getContentPane().add(btnSort);

				btnClear = new JButton("Clear");
				btnClear.setToolTipText("Clear");
				btnClear.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
				btnClear.setBounds(315, 160, 140, 24);
				getContentPane().add(btnClear);

				Picture p = new Picture (10, 10, new ImageIcon("logo.png"));
				p.setLocation(491, 37);
				p.setSize(234, 100);
				getContentPane().add(p);

				btnClear.addActionListener(this);
				btnHome.addActionListener(this);
				btnSort.addActionListener(this);
				btnLoadFile.addActionListener(this);
				btnSaveFile.addActionListener(this);
				btnExit.addActionListener(this);

				if (LoginGUI.check == true) // Too load information
				{
					txtAccountInfo.append(accountInfo(LoginGUI.file));
				}

				if (CreateAccount.check == true)
				{
					txtAccountInfo.append(accountInfo(CreateAccount.file));
				}
				setVisible (true);
			}

			/*
			 * Method to load account information from file
			 */
			public String accountInfo(String file)
			{
				try {
					FileReader In = new FileReader (file); 
					BufferedReader inputFile = new BufferedReader (In);
					username = inputFile.readLine();
					password = inputFile.readLine();
					name = inputFile.readLine();
					address = inputFile.readLine();
					phone = inputFile.readLine();
					accountNum = inputFile.readLine();
					inputFile.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				return "Name: " + name + "\n" + "Address: " + address + "\n" + "Phone: " + phone + "\n" + "Account #: " + accountNum;
			}

			/*
			 * Method to output transaction record based on parameters
			 */
			public String outputText(JTextArea amtIn, Object account, char cs, String dw)
			{
				double amt = Double.parseDouble(amtIn.getText());
				currentBalance = ((Account) account).getBalance();
				((Account) account).deposit(amt);
				TransactionRecord record = new TransactionRecord (cs, dw, amt, currentBalance, ((Account) account).getBalance());
				transactionList.insert(record);
				output += record.toString() + "\n";
				return output;
			}

			/*
			 * Method for button listening
			 */
			public void actionPerformed(ActionEvent e) 
			{	
				if (e.getSource() == btnClear)
				{
					txtTransactionList.setText("");
				}

				//		if (e.getSource() == btnSort)
				//		{
				//			record.insertionSort();
				//		}

				if (e.getSource() == btnHome) // Home
				{
					dispose();
					new LoginGUI();
				}

				if (e.getSource() == btnExit) // Exit
				{
					System.exit(0);
				}

				if (e.getSource() == btnWithdraw) // Withdraw
				{
					double amt = Double.parseDouble(txtWithdraw.getText());
					if (type == "Chequing") // withdraw from chequing
					{
						if (!chequingAcct.withdraw(amt)) 
						{
							JOptionPane.showMessageDialog(null, "Insufficient funds");
						}
						else
						{
							txtTransactionList.setText(outputText(txtWithdraw, chequingAcct, 'c', "w"));
						}
					}
					else if (type == "Savings") // withdraw from savings
					{
						if (!savingsAcct.withdraw(amt)) 
						{
							JOptionPane.showMessageDialog(null, "Insufficient funds");
						}
						else
						{
							txtTransactionList.setText(outputText(txtWithdraw, savingsAcct, 's', "w"));
						}
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Please choose Chequing or Savings!", "Error", JOptionPane.ERROR_MESSAGE);
					}
				}

				if (e.getSource() == btnDeposit)  // Deposit
				{
					if (type == "Chequing") // deposit to chequing
					{
						txtTransactionList.setText(outputText(txtDeposit, chequingAcct, 'c', "d"));
					}
					else if (type == "Savings") // deposit to savings
					{
						txtTransactionList.setText(outputText(txtDeposit, savingsAcct, 's', "d"));
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Please choose Chequing or Savings!", "Error", JOptionPane.ERROR_MESSAGE);
					}
				}

				if (e.getSource() == btnLoadFile) // Load file
				{
					txtAccountInfo.append(accountInfo(JOptionPane.showInputDialog(null, "Enter Account Username", "Admin.txt")));
				}

				if (e.getSource() == btnSaveFile) // Save file
				{
					transactionList.insert(info);
					try {
						transactionList.saveToFile();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}

			public static void main(String[] args) 
			{
				new CustomerAccount ();
			}
}
