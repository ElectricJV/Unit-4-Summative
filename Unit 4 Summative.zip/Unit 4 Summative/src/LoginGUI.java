import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.awt.*;
import javax.swing.*;

/**
 * 
 */

/**
 * @author Joshua & Muhammad
 * Date: May 2017
 * Description: This program is the login screen for the main program
 * Method List:
 * 		LoginGUI() -- default constructor 
 * 		boolean login() -- boolean login check
 * 		void actionPerformed(ActionEvent) --  button listening
 * 		void main(String[]) -- self testing main
 */
public class LoginGUI extends JFrame implements ActionListener {
	// GUI variables
	private JLabel lUsername, lPassword;
	private JTextField tUser;
	private JTextField tPass;
	private JTextArea output;
	private JButton bLogin, bClose, bCreateAccount;
	private Picture logo;
	private Container frame;
	// Variables for decisions and filename
	static boolean check;
	static String file;
	private String fileName;

	/**
	 * Defailt constructor
	 */
	public LoginGUI() {
		super ("Login");
		setSize (500, 500);
		setLocation (720, 200);
		setDefaultCloseOperation (EXIT_ON_CLOSE); //exits on close
		frame = getContentPane();

		setUndecorated (true);
		frame.setLayout (null);
		setResizable (false);
		// Make password fields
		lUsername = new JLabel("Username");
		lPassword = new JLabel("Password");
		tUser = new JTextField ("");
		tPass = new JPasswordField (10);
		bLogin = new JButton("Login");
		bClose = new JButton("Close");
		frame.setLayout(null);

		// Placing the components
		lUsername.setBounds (90, 200, 100, 15);   // Username
		frame.add (lUsername);

		lPassword.setBounds (90, 245, 100, 15);  // Password
		frame.add (lPassword);

		tUser.setBounds (170, 200, 175, 25);  // Username
		frame.add (tUser);

		tPass.setBounds (170, 245, 175, 25); // Password
		frame.add (tPass);

		bLogin.setBounds (75, 325, 150, 25);    // Login button
		frame.add (bLogin);

		bClose.setBounds (250, 325, 150, 25);  // Close button
		frame.add (bClose);

		bCreateAccount = new JButton("Create Account");
		bCreateAccount.setBounds(170, 376, 150, 25);
		getContentPane().add(bCreateAccount);

		//		logo = new Picture(new ImageIcon("DiamondBankLogo.png"), 10, 10);
		//		frame.add (logo);

		// Display in the centre
		Dimension dim = Toolkit.getDefaultToolkit ().getScreenSize ();
		this.setLocation (dim.width / 2 - this.getSize ().width / 2, dim.height / 2 - this.getSize ().height / 2);

		bLogin.addActionListener(this);
		bClose.addActionListener(this);
		bCreateAccount.addActionListener(this);

		setVisible(true);
		setResizable(false);
	}

	/*
	 * Method for boolean login check
	 */
	public boolean login() throws IOException
	{  
		// Create password and username
		String password = "";
		String userName = "";

		try{
			// Open from file and read first two lines for username and pass
			fileName = JOptionPane.showInputDialog(null, "Enter Account Username", "Admin.txt");
			FileReader In = new FileReader (fileName); 
			BufferedReader inputFile = new BufferedReader (In);
			userName = inputFile.readLine();
			password = inputFile.readLine();
			inputFile.close();
		} catch(Exception e){

		}
		if(tUser.getText().equalsIgnoreCase(userName) && tPass.getText().equalsIgnoreCase(password)){ // If password and username match return true
			return true;
		}
		return false;
	}

	/*
	 * Action performed method for button listening
	 */
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource () == bLogin) 
		{
			try {
				if(login()==true)
				{
					JOptionPane.showMessageDialog(null,"Logged In");
					super.dispose();
					check = true;
					file = fileName;
					new CustomerAccount();                                   
				}
				else
				{ 
					JOptionPane.showMessageDialog(null,"Error");
					//sets text fields back to empty
					tUser.setText("");
					tPass.setText("");                                                
				}
			} catch (HeadlessException | IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}            
		}
		if(e.getSource() == bCreateAccount)
		{
			new CreateAccount();
		}
		else if(e.getSource() == bClose)
		{
			System.exit(0);
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		new LoginGUI();
	}
}
